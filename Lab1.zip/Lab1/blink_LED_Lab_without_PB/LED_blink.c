#include <xc.h>

// Configuration settings
#pragma config FOSC = HS        // Oscillator Selection bits (HS oscillator)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config BOREN = ON       // Brown-out Reset Enable bit (BOR enabled)
#pragma config LVP = OFF        // Low-Voltage (Single-Supply) In-Circuit Serial Programming Enable bit (RB3 is digital I/O, HV on MCLR must be used for programming)
#pragma config CPD = OFF        // Data EEPROM Memory Code Protection bit (Data EEPROM code protection off)
#pragma config WRT = OFF        // Flash Program Memory Write Enable bits (Write protection off; all program memory may be written to by EECON control)
#pragma config CP = OFF         // Flash Program Memory Code Protection bit (Code protection off)

#define _XTAL_FREQ 4000000 // Crystal frequency, 4 MHz

void main(void) {
    // Set LED pins as output
    TRISB0 = 0;  // RB0 (Green LED)
    TRISC1 = 0;  // RC1 (Red LED)
    TRISD2 = 0;  // RD2 (Blue LED)
    TRISA3 = 0;  // RA3 (Yellow LED)
    TRISE0 = 0;  // RE0 (Purple LED)

    while (1) {
        // Blink all LEDs simultaneously
        RB0 = 1;  // Turn on the Green LED
        RC1 = 1;  // Turn on the Red LED
        RD2 = 1;  // Turn on the Blue LED
        RA3 = 1;  // Turn on the Yellow LED
        RE0 = 1;  // Turn on the Purple LED

        __delay_ms(500);  // Delay 500 ms

        RB0 = 0;  // Turn off the Green LED
        RC1 = 0;  // Turn off the Red LED
        RD2 = 0;  // Turn off the Blue LED
        RA3 = 0;  // Turn off the Yellow LED
        RE0 = 0;  // Turn off the Purple LED

        __delay_ms(500);  // Delay 500 ms
    }
}
