#include <xc.h>

// Configuration settings
#pragma config FOSC = HS
#pragma config WDTE = OFF
#pragma config PWRTE = OFF
#pragma config BOREN = ON
#pragma config LVP = OFF
#pragma config CPD = OFF
#pragma config WRT = OFF
#pragma config CP = OFF

#define _XTAL_FREQ 4000000

void main(void) {
    // Set LED pins as output
    TRISB0 = 0;  // RB0 (Green LED)
    TRISC1 = 0;  // RC1 (Red LED)
    TRISD2 = 0;  // RD2 (Blue LED)
    TRISA3 = 0;  // RA3 (Yellow LED)
    TRISE0 = 0;  // RE0 (Purple LED)

    // Set push button pin as input with internal pull-up resistor
    TRISA4 = 1;  // RA4 (Push button)
    OPTION_REGbits.nRBPU = 0;  // Enable internal pull-up resistor for PORTA

    int buttonState = 0;  // Variable to track button state
    int ledsOn = 0;      // Variable to track LED state

    while (1) {
        // Check if the button is pressed
        if (PORTAbits.RA4 == 0) {
            // Check if the button was not pressed before (rising edge)
            if (!buttonState) {
                // Toggle button state
                buttonState = 1;

                // Toggle LEDs based on the current state
                ledsOn = !ledsOn;

                // Set all LEDs based on the LED state
                RB0 = ledsOn;  // Green LED
                RC1 = ledsOn;  // Red LED
                RD2 = ledsOn;  // Blue LED
                RA3 = ledsOn;  // Yellow LED
                RE0 = ledsOn;  // Purple LED
            }
        } else {
            // Reset button state when the button is released
            buttonState = 0;
        }
    }
}
